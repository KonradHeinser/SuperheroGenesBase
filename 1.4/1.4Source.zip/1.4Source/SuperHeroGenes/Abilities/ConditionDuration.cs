﻿using Verse;
namespace SuperHeroGenesBase
{
    public class ConditionDuration
    {
        public GameConditionDef condition;
        public int ticks = 60000;
    }
}
