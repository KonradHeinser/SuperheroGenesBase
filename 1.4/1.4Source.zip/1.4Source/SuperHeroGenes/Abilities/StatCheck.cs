﻿using RimWorld;
namespace SuperHeroGenesBase
{
    public class StatCheck
    {
        public StatDef stat;
        public float minStatValue = 0f;
        public float maxStatValue = 99999f;
    }
}
