﻿using RimWorld;

namespace SuperHeroGenesBase
{
    public class NeedOffset
    {
        public NeedDef need;
        public float offset;
        public StatDef offsetFactorStat;
    }
}
