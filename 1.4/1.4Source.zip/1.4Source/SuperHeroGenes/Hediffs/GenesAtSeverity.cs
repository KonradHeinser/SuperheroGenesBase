﻿using Verse;
using System.Collections.Generic;

namespace SuperHeroGenesBase
{
    public class GenesAtSeverity
    {
        public float minSeverity = 0;

        public float maxSeverity = 999;

        public bool xenogenes = true;

        public List<GeneDef> genes;
    }
}
