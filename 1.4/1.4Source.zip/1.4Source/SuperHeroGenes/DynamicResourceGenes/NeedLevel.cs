﻿using RimWorld;

namespace SuperHeroGenesBase
{
    public class NeedLevel
    {
        public NeedDef need;
        public float minNeedLevel = 0f;
        public float maxNeedLevel = 1f;
    }
}
